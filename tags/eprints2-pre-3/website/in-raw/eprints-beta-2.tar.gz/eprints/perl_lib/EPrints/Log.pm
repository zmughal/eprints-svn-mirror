######################################################################
#
# EPrints Logging Utility
#
#  Handy stuff for using log files.
#
######################################################################
#
# License for eprints.org software version: Beta-2 (19/9/2000)
# 
# Copyright (C) 2000, University of Southampton
# 
# The University of Southampton retains the copyright of the core
# components of this system with the exception of the open archives
# component (in the openarchives/ directory), which is a modified
# version of code distributed by Cornell University Digital Library
# Research Group.
# 
# This version of the software may be used only for testing and
# evaluation purposes. It is not suitable for a live service. There
# can be no guarantee that data and configuration information entered
# into this version will be directly transferable the final
# production release.
# 
# Users of this beta are asked to provide bug reports, feedback and
# suggestions to the eprints.org bug tracking system located at:
# 
#   http://bugs.eprints.org/
# 
# This software is provided with no guarantees of suitability for any
# intended purpose. Use of the software is entirely at the end user's
# risk.
#
######################################################################

package EPrints::Log;


######################################################################
#
# GLOBAL DEBUG FLAG! Set this to 1 if debug information should be
# written to logs.
#
######################################################################

my $debug = 1;



######################################################################
#
# log_entry( $name, $msg )
#
#  Write a log message. Log messages are always written during the
#  normal course of operation. Accordingly, log messages should be
#  concise; for finer-grained messages to use during debugging, use
#  debug(). $name should be something useful (like the module name.)
#
######################################################################

sub log_entry
{
	my( $name, $msg ) = @_;
	
	print STDERR "$name: $msg\n";

#	my $log_filename = "$EPrintSite::SiteInfo::log_path/$name.log";
#
#	if( -e $log_filename )
#	{
#		open LOGFILE, ">>$log_filename";
#	}
#	else
#	{
#		open LOGFILE, ">$log_filename";
#	}
#
#	print LOGFILE "$name: $msg\n" if( defined $log_filename );
#
#	close LOGFILE;
}


######################################################################
#
# debug( $name, $msg )
#
#  Write a debug message out to a log, if debugging is switched on.
#
######################################################################

sub debug
{
	my( $name, $msg ) = @_;

	if( $debug )
	{
#		if( $name eq "submit" )
#		{
#			print "$name - $msg\n";
#		}
#		else
#		{
		print STDERR "$name: $msg\n";
#		}

#		my $log_filename = "$EPrintSite::SiteInfo::log_path/$name.log";
#
#print STDERR "<P>Log file is $log_filename</P>\n";
#
#		if( -e $log_filename )
#		{
#			open LOGFILE, ">>$log_filename";
#		}
#		else
#		{
#			open LOGFILE, ">$log_filename";
#		}
#
#		print LOGFILE "$name: $msg\n" if( defined $log_filename );
#
#		close LOGFILE;
	}
}


1;
